﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_del_Portafolio_9
{
    internal class Program
    {
        static void Main(string[] args)
        {       //Persona1
            Persona persona1 = new Persona();
            persona1.nombre = "Isabel";
            Console.WriteLine(persona1.nombre);
            persona1.apellido = "Carranza";
            Console.WriteLine(persona1.apellido);
            persona1.edad = 28;
            Console.WriteLine(persona1.edad);
            persona1.telefono = 86782345;
            Console.WriteLine(persona1.telefono);
            persona1.correoElectronico = "isabelC@hotmail.com";
            Console.WriteLine(persona1.correoElectronico);
            persona1.genero = "femenino";
            Console.WriteLine(persona1.genero);
            Console.WriteLine();
            //Persona2
            Persona persona2 = new Persona(29, "masculino");
            Console.WriteLine("Nombre Completo: " + persona2.ObtenerNombreCompleto());
            Console.WriteLine("Edad: " + persona2.edad);
            Console.WriteLine("Género: " + persona2.genero);
            Console.WriteLine();
            //se utiliza la funcionalidad del método para modificar los datos de una persona, por ejemplo:
            //persona2.ActualizarInformacion("Juan", "Abarca", 40, 6789976, "juanA@gmail.com", "masculino");

            //CLASE LIBRO
            // Crear objetos de la clase Libro
            libro libro1 = new libro();
            libro libro2 = new libro("El Gran Gatsby", "F. Scott Fitzgerald", "Novela", 1925, 10, 15000); //objetos asignando valores a los atributos y sin asignar
            //setter
            libro1.titulo = "Cien años de soledad";
            libro1.autor = "Gabriel García Márquez"; 
            libro1.genero = "Novela";
            libro1.anioPublicacion = 1967;
            libro1.stock = 5;
            libro1.precio = 20000;
            //Con el método Obtner información se omite él usar solo un "get" para consultar un atributo del objeto en particular y revisamos todos
            Console.WriteLine("Libro 1:");
            Console.WriteLine(libro1.ObtenerInformacionLibro());
            Console.WriteLine();
            Console.WriteLine("Libro 2:");
            Console.WriteLine(libro2.ObtenerInformacionLibro());
            Console.ReadKey();
        }
    }
    class Persona
    {
        public string nombre { get; set; }     //Aunque el atributo se declara como público (public), el campo privado asociado
                                               //a la propiedad se mantiene privado y no puede ser accedido directamente desde fuera de la clase.
        public string apellido { get; set; }
        public int edad { get; set; }
        public int telefono { get; set; }
        public string correoElectronico { get; set; }
        public string genero { get; set; }

        //constructor
        public Persona()
        {

            nombre = "";
            apellido = "";
            edad = 0;
            telefono = 0;
            correoElectronico = "";  //CONSTRUCTOR VACÍO
            genero = "";


        }
        public Persona(string nombre, string apellido, int edad, int telefono, string correoElectronico, string genero)
        {

            this.nombre = nombre;
            this.apellido = apellido;         //CONSTRUCTOR CON TODOS LOS PARAMETROS
            this.edad = edad;
            this.telefono = telefono;
            this.correoElectronico = correoElectronico;
            this.genero = genero;


        }
        public Persona(int edad, string genero) //CONSTRUCTO CON DOS PARAMETOS Y EL RESTO YA ASIGNADO
        {

            nombre = "Carlos";
            apellido = "Abarca";
            this.edad = edad;
            telefono = 4562347;
            correoElectronico = "carlosA@gmail.com";
            this.genero = genero;


        }
        public Persona(int telefono)
        {

            nombre = "";
            apellido = "";
            edad = 0;
            this.telefono = telefono;
            correoElectronico = "";
            genero = "";


        }

        public string ObtenerNombreCompleto()
        {
            return nombre + " " + apellido;
        }

        // Método setter para modificar varios atributos a la vez
        public void ActualizarInformacion(string nombre, string apellido, int edad, int telefono, string correoElectronico, string genero)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
            this.telefono = telefono;
            this.correoElectronico = correoElectronico;
            this.genero = genero;
        }
    }

    ///CLASE LIBRO////

    class libro        //nueva forma de implementar de la manera mas abreviada posible los getter y setter
    {
        public string titulo { get; set; }
        public string autor { get; set; }
        public string genero { get; set; }
        public int anioPublicacion { get; set; }
        public int stock { get; set; }
        public decimal precio { get; set; }

        //constructor
        public libro()
        {
            titulo = "";
            autor = "";
            genero = "";
            anioPublicacion = 0;
            stock = 0;
            precio = 0;

        }

        public libro(string titulo, string autor, string genero, int anioPublicacion, int stock, decimal precio)
        {
            this.titulo = titulo;
            this.autor = autor;
            this.genero = genero;
            this.anioPublicacion = anioPublicacion;
            this.stock = stock;
            this.precio =precio;

        }
        public string ObtenerInformacionLibro()
        {
            string informacion = $"Título: {titulo}\n" +
                                 $"Autor: {autor}\n" +
                                 $"Género: {genero}\n" +
                                 $"Año de publicación: {anioPublicacion}\n" +
                                 $"Stock: {stock}\n" +
                                 $"Precio: {precio:F2}"; //F2 especifica formato con solo dos decimales
            return informacion;

        }

        public void ActualizarInformacion(string titulo, string autor, string genero, int anioPublicacion, int stock, decimal precio)
        {
            this.titulo = titulo;
            this.autor = autor;
            this.genero = genero;
            this.anioPublicacion = anioPublicacion;
            this.stock = stock;
            this.precio = precio;
        }




    }
}
